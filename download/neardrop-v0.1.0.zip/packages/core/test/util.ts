import type { ChannelLike } from '../src/index.js';
import type { FileMeta, FileSource, ByteSink, SinkHandle } from '../src/index.js';

export const wait = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

interface MockPairOpts {
  /** drain at most this many bytes per tick (default: unlimited) */
  bytesPerTick?: number;
  tickMs?: number;
}

/** RTCDataChannel-like mock with realistic bufferedAmount accounting + drain rate. */
export class MockChannel extends EventTarget implements ChannelLike {
  readonly label: string;
  readyState: 'connecting' | 'open' | 'closing' | 'closed' = 'open';
  bufferedAmount = 0;
  bufferedAmountLowThreshold = 0;

  peer: MockChannel | null = null;
  readonly stats = { sends: 0, bytesSent: 0, maxBufferedSeen: 0 };

  private queue: Array<{ bytes: number; data: ArrayBuffer }> = [];
  private opts: Required<MockPairOpts>;
  private pumping = false;

  constructor(label: string, opts: MockPairOpts = {}) {
    super();
    this.label = label;
    this.opts = { bytesPerTick: opts.bytesPerTick ?? Infinity, tickMs: opts.tickMs ?? 1 };
  }

  send(data: string | ArrayBuffer | ArrayBufferView): void {
    if (this.readyState !== 'open') throw new Error(`MockChannel(${this.label}): send on ${this.readyState}`);
    if (typeof data === 'string') {
      const text = data;
      queueMicrotask(() => {
        if (this.peer && this.peer.readyState === 'open') {
          this.peer.dispatchEvent(new MessageEvent('message', { data: text }));
        }
      });
      return;
    }
    const buf = data instanceof ArrayBuffer
      ? data
      : (data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer);
    this.bufferedAmount += buf.byteLength;
    this.stats.sends += 1;
    this.stats.bytesSent += buf.byteLength;
    this.stats.maxBufferedSeen = Math.max(this.stats.maxBufferedSeen, this.bufferedAmount);
    this.queue.push({ bytes: buf.byteLength, data: buf });
    this.pump();
  }

  private pump(): void {
    if (this.pumping) return;
    this.pumping = true;
    const step = () => {
      let budget = this.opts.bytesPerTick;
      while (this.queue.length > 0 && budget > 0) {
        const item = this.queue.shift()!;
        budget -= item.bytes;
        this.bufferedAmount -= item.bytes;
        if (this.peer && this.peer.readyState === 'open') {
          this.peer.dispatchEvent(new MessageEvent('message', { data: item.data }));
        }
      }
      if (this.bufferedAmount <= this.bufferedAmountLowThreshold && this.stats.maxBufferedSeen > 0) {
        this.dispatchEvent(new Event('bufferedamountlow'));
      }
      if (this.queue.length > 0) {
        setTimeout(step, this.opts.tickMs);
      } else {
        this.pumping = false;
      }
    };
    // deferred first tick: the drain rate is then genuinely bytesPerTick/tickMs
    setTimeout(step, this.opts.tickMs);
  }

  close(): void {
    if (this.readyState === 'closed') return;
    this.readyState = 'closed';
    this.queue.length = 0;
    this.bufferedAmount = 0;
    this.dispatchEvent(new Event('close'));
    const peer = this.peer;
    queueMicrotask(() => {
      if (peer && peer.readyState === 'open') {
        peer.readyState = 'closed';
        peer.dispatchEvent(new Event('close'));
      }
    });
  }
}

export interface MockPair {
  a: MockChannel;
  b: MockChannel;
}

/** A linked pair [a→b, b→a]. Messages sent on `a` are received by `b` and vice versa. */
export function mockPair(label: string, opts: MockPairOpts = {}): MockPair {
  const a = new MockChannel(`${label}:a`, opts);
  const b = new MockChannel(`${label}:b`, opts);
  a.peer = b;
  b.peer = a;
  return { a, b };
}

/** Deterministic synthetic file (repeating 0..255 byte pattern). */
export class MemoryFile implements FileSource {
  readonly meta: FileMeta;

  constructor(name: string, size: number, type = 'application/octet-stream') {
    this.meta = { name, size, type };
  }

  stream(start = 0): ReadableStream<Uint8Array> {
    const size = this.meta.size;
    let pos = start;
    return new ReadableStream<Uint8Array>({
      pull(controller) {
        if (pos >= size) {
          controller.close();
          return;
        }
        const end = Math.min(size, pos + 512 * 1024);
        const chunk = new Uint8Array(end - pos);
        for (let i = 0; i < chunk.length; i++) chunk[i] = (pos + i) & 0xff;
        pos = end;
        controller.enqueue(chunk);
      },
    });
  }
}

/** Text file with compressible content. */
export class TextFile implements FileSource {
  readonly meta: FileMeta;

  constructor(name: string, size: number, type = 'text/plain') {
    this.meta = { name, size, type };
  }

  stream(start = 0): ReadableStream<Uint8Array> {
    const size = this.meta.size;
    let pos = start;
    const line = 'the quick brown fox jumps over the lazy dog — NearDrop protocol test payload\n';
    const lineBytes = new TextEncoder().encode(line);
    return new ReadableStream<Uint8Array>({
      pull(controller) {
        if (pos >= size) {
          controller.close();
          return;
        }
        const end = Math.min(size, pos + 256 * 1024);
        const chunk = new Uint8Array(end - pos);
        for (let off = 0; off < chunk.length; off += lineBytes.length) {
          chunk.set(lineBytes.subarray(0, Math.min(lineBytes.length, chunk.length - off)), off);
        }
        pos = end;
        controller.enqueue(chunk);
      },
    });
  }
}

/** In-memory sink for verification. */
export class MemorySink implements ByteSink {
  chunks: Uint8Array[] = [];
  bytes = 0;
  closed = false;
  aborted = false;

  write(chunk: Uint8Array): void {
    const copy = chunk.slice();
    this.chunks.push(copy);
    this.bytes += copy.length;
  }

  close(): void {
    this.closed = true;
  }

  abort(): void {
    this.aborted = true;
  }
}

/** Sink that only counts (for huge files where we don't want copies). */
export class CountingSink implements ByteSink {
  bytes = 0;
  closed = false;
  write(chunk: Uint8Array): void {
    this.bytes += chunk.byteLength;
  }
  close(): void {
    this.closed = true;
  }
}

export function sinkHandle(sink: ByteSink, startBytes = 0): SinkHandle {
  return { sink, startBytes, persist: false };
}

/** Quick sink factory that hands out one sink per file index. */
export function sinkMap() {
  const sinks = new Map<number, ByteSink>();
  const factory = (index: number): SinkHandle => {
    let s = sinks.get(index);
    if (!s) {
      s = new MemorySink();
      sinks.set(index, s);
    }
    return sinkHandle(s);
  };
  return { sinks, factory };
}

/** Grab the File handle factory style used in tests: (i, meta, resume) => Promise<SinkHandle | null> */
export const makeFactory =
  (sinks: Map<number, ByteSink>) =>
  async (index: number): Promise<SinkHandle> => {
    let s = sinks.get(index);
    if (!s) {
      s = new MemorySink();
      sinks.set(index, s);
    }
    return sinkHandle(s);
  };
