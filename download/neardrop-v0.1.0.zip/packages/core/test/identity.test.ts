import { describe, expect, it } from 'vitest';
import {
  generateIdentity, importIdentity, signBytes, verifyBytes,
  deviceIdFromJwk, randomName, verificationEmoji, Handshake,
} from '../src/index.js';
import { mockPair } from './util.js';
import { parseControl } from '../src/index.js';

describe('identity', () => {
  it('generates an identity with a stable deviceId', async () => {
    const id = await generateIdentity();
    expect(id.deviceId).toBe(deviceIdFromJwk(id.alg, id.publicJwk));
    expect(id.deviceId).toHaveLength(16);
  });

  it('round-trips through JWK persistence', async () => {
    const id = await generateIdentity();
    const privateJwk = await crypto.subtle.exportKey('jwk', id.privateKey);
    const restored = await importIdentity(id.alg, id.publicJwk, privateJwk);
    expect(restored.deviceId).toBe(id.deviceId);
    const msg = new TextEncoder().encode('hello neardrop');
    const sig = await signBytes(restored, msg);
    expect(await verifyBytes(id.alg, id.publicJwk, msg, sig)).toBe(true);
  });

  it('rejects a tampered signature', async () => {
    const id = await generateIdentity();
    const other = await generateIdentity();
    const msg = new TextEncoder().encode('payload');
    const sig = await signBytes(other, msg);
    expect(await verifyBytes(id.alg, id.publicJwk, msg, sig)).toBe(false);
  });
});

describe('handshake', () => {
  it('mutually verifies both peers over a mock control channel', async () => {
    const { a, b } = mockPair('hs');
    const idA = await generateIdentity();
    const idB = await generateIdentity();

    const hA = new Handshake({ identity: idA, name: 'Alpha', deviceType: 'desktop' });
    const hB = new Handshake({ identity: idB, name: 'Beta', deviceType: 'phone' });

    // wire: route parsed control messages into handshakes first
    const wire = (ch: typeof a, h: Handshake) => {
      ch.addEventListener('message', (e: Event) => {
        const msg = parseControl((e as MessageEvent).data as string);
        if (msg && h.handle(msg)) return;
      });
      h.start((m) => ch.send(JSON.stringify(m)));
    };
    wire(a, hA);
    wire(b, hB);

    const [peerA, peerB] = await Promise.all([hA.result, hB.result]);
    expect(peerA.name).toBe('Beta');
    expect(peerA.deviceId).toBe(idB.deviceId);
    expect(peerB.name).toBe('Alpha');
    expect(peerB.deviceId).toBe(idA.deviceId);
  });

  it('fails when the peer signs with a different key than it declared (MITM)', async () => {
    const { a, b } = mockPair('hs-bad');
    const idA = await generateIdentity();
    const idB = await generateIdentity();
    const idC = await generateIdentity(); // impostor key
    const hA = new Handshake({ identity: idA, name: 'Alpha', deviceType: 'desktop' }, 2000);
    // B declares idB's public key in hello but actually holds idC's private key
    const impostor = { deviceId: idB.deviceId, alg: idB.alg, publicJwk: idB.publicJwk, privateKey: idC.privateKey };
    const hB = new Handshake({ identity: impostor, name: 'Beta', deviceType: 'phone' }, 2000);
    const wire = (ch: typeof a, h: Handshake) => {
      ch.addEventListener('message', (e: Event) => {
        const msg = parseControl((e as MessageEvent).data as string);
        if (msg && h.handle(msg)) return;
      });
      h.start((m) => ch.send(JSON.stringify(m)));
    };
    wire(a, hA);
    wire(b, hB);
    await expect(hA.result).rejects.toThrow();
  });
});

describe('naming + emoji verification', () => {
  it('produces adjective-animal names', () => {
    for (let i = 0; i < 10; i++) {
      expect(randomName()).toMatch(/^[A-Z][a-z]+ [A-Z][a-z]+$/);
    }
  });

  it('verification emoji is symmetric and stable', () => {
    const ab = verificationEmoji('deadbeefdeadbeef', '0011223344556677');
    const ba = verificationEmoji('0011223344556677', 'deadbeefdeadbeef');
    expect(ab).toEqual(ba);
    expect(ab).toHaveLength(4);
    expect(verificationEmoji('deadbeefdeadbeef', '0011223344556677')).toEqual(ab);
  });

  it('different pairs get (almost certainly) different codes', () => {
    const x = verificationEmoji('1111111111111111', '2222222222222222').join('');
    const y = verificationEmoji('3333333333333333', '4444444444444444').join('');
    expect(x).not.toBe(y);
  });
});
