import { describe, expect, it, beforeEach } from 'vitest';
import {
  TransferSender, TransferReceiver, negotiateChunkSize, DEFAULT_CONFIG,
  type TransferConfig, type FileSource, type SinkHandle, type ByteSink,
  Sha256, DEFAULT_CONFIG as CFG,
} from '../src/index.js';
import { mockPair, MemoryFile, TextFile, MemorySink, CountingSink, sinkHandle, wait, MockChannel } from './util.js';

const MB = 1024 * 1024;

interface TestEnv {
  sender: TransferSender;
  receiver: TransferReceiver;
  dataA: import('../src/index.js').ChannelLike[];
  dataB: import('../src/index.js').ChannelLike[];
  controlPair: ReturnType<typeof mockPair>;
  sinks: Map<number, ByteSink>;
}

function makeEnv(files: FileSource[], cfgOverrides: Partial<TransferConfig> = {}, drainBytesPerTick?: number): TestEnv {
  const merged: Partial<TransferConfig> = { ...cfgOverrides };
  const controlPair = mockPair('control');
  const dataA: import('../src/index.js').ChannelLike[] = [];
  const dataB: import('../src/index.js').ChannelLike[] = [];
  for (let i = 0; i < (merged.parallelChannels ?? DEFAULT_CONFIG.parallelChannels); i++) {
    const p = mockPair(`data-${i}`, drainBytesPerTick ? { bytesPerTick: drainBytesPerTick, tickMs: 1 } : {});
    dataA.push(p.a);
    dataB.push(p.b);
  }
  const sinks = new Map<number, ByteSink>();
  const sinkFor = async (index: number): Promise<SinkHandle> => {
    let s = sinks.get(index);
    if (!s) {
      s = new MemorySink();
      sinks.set(index, s);
    }
    return sinkHandle(s);
  };
  const sender = new TransferSender({ id: 't1', files, config: merged });
  sender.attach({ control: controlPair.a, data: dataA });
  const receiver = new TransferReceiver({ sinkFor, config: merged });
  receiver.attach({ control: controlPair.b, data: dataB });
  receiver.on('offer', () => {
    void receiver.userAccept();
  });
  return { sender, receiver, dataA, dataB, controlPair, sinks };
}

async function sinkHex(sink: ByteSink): Promise<string> {
  const h = new Sha256();
  for (const c of (sink as MemorySink).chunks) h.update(c);
  return h.digestHex();
}

async function sourceHex(f: FileSource): Promise<string> {
  const h = new Sha256();
  const reader = f.stream(0).getReader();
  for (;;) {
    const r = await reader.read();
    if (r.done) break;
    h.update(r.value);
  }
  return h.digestHex();
}
describe('end-to-end transfers (mock channels)', () => {
  it('transfers 3 mixed-size files incl. a zero-byte file, with hash verification', async () => {
    const files = [
      new MemoryFile('tiny.bin', 0),
      new MemoryFile('small.bin', 31 * 1024 + 7),
      new TextFile('notes.txt', 300 * 1024),
    ];
    const env = makeEnv(files, { chunkSize: 16 * 1024, parallelThresholdBytes: 64 * 1024, parallelChannels: 4, verifyThresholdBytes: MB });
    const fileDoneEvents: number[] = [];
    env.receiver.on('fileDone', (e) => fileDoneEvents.push(e.fileIndex));
    const senderDone = env.sender.run();
    const result = await senderDone;
    expect(result).toBe('complete');
    expect(fileDoneEvents.sort()).toEqual([0, 1, 2]);
    expect(env.sinks.size).toBe(3);
    expect((env.sinks.get(0)! as MemorySink).bytes).toBe(0);
    for (let i = 0; i < files.length; i++) {
      expect(await sinkHex(env.sinks.get(i)!)).toBe(await sourceHex(files[i]!));
    }
    const small = env.sinks.get(1)! as MemorySink;
    expect(small.bytes).toBe(31 * 1024 + 7);
    const txt = env.sinks.get(2)! as MemorySink;
    expect(txt.bytes).toBe(300 * 1024);
  });

  it('uses 4 parallel channels for large files and reassembles correctly', async () => {
    const files = [new MemoryFile('big.bin', 6 * MB)];
    const env = makeEnv(files, {
      chunkSize: 128 * 1024,
      parallelThresholdBytes: MB,
      parallelChannels: 4,
      highWaterBytes: 512 * 1024,
      lowThresholdBytes: 128 * 1024,
      verifyThresholdBytes: MB,
    });
    await env.sender.run();
    const sink = env.sinks.get(0)! as MemorySink;
    expect(sink.bytes).toBe(6 * MB);
    expect(await sinkHex(sink)).toBe(await sourceHex(files[0]!));
    // out-of-order window must stay bounded
    expect(env.receiver.stats.maxPendingBytes).toBeLessThanOrEqual(128 * 1024 * 16);
  });

  it('gzips text-like files and verifies the decompressed hash', async () => {
    if (typeof globalThis.CompressionStream !== 'function' || typeof globalThis.DecompressionStream !== 'function') {
      return; // ancient runtime: skip
    }
    const files = [new TextFile('log.txt', 4 * MB, 'text/plain')];
    const env = makeEnv(files, { chunkSize: 64 * 1024, verifyThresholdBytes: MB });
    await env.sender.run();
    const sink = env.sinks.get(0)! as MemorySink;
    expect(sink.bytes).toBe(4 * MB);
    expect(await sinkHex(sink)).toBe(await sourceHex(files[0]!));
  });

  it('rejects when receiver declines', async () => {
    const files = [new MemoryFile('a.bin', 1024)];
    const controlPair = mockPair('control');
    const dp = mockPair('data-0');
    const sender = new TransferSender({ id: 't2', files, config: { chunkSize: 16 * 1024 } });
    sender.attach({ control: controlPair.a, data: [dp.a] });
    const receiver = new TransferReceiver({
      sinkFor: async () => sinkHandle(new MemorySink()),
      config: { chunkSize: 16 * 1024 },
    });
    receiver.attach({ control: controlPair.b, data: [dp.b] });
    receiver.on('offer', () => receiver.userReject('not now'));
    await expect(sender.run()).resolves.toBe('rejected');
  });

  it('cancel propagates: sender.cancel() stops the receiver', async () => {
    const files = [new MemoryFile('huge.bin', 512 * MB)];
    const env = makeEnv(files, {
      chunkSize: 256 * 1024,
      highWaterBytes: 8 * MB,
      lowThresholdBytes: 1 * MB,
      parallelChannels: 1,
    }, 256 * 1024); // drain 256MB/s → 512MB needs ~2s; cancel at 200ms is mid-flight
    const cancelled = new Promise<void>((res) => env.receiver.on('cancelled', () => res()));
    const running = env.sender.run();
    await wait(200);
    env.sender.cancel('changed my mind');
    await cancelled;
    await expect(running).resolves.toBe('cancelled');
  });
});

describe('backpressure', () => {
  it('sender pauses when bufferedAmount > highWater and resumes on bufferedamountlow', async () => {
    const chunkSize = 256 * 1024;
    const highWater = 2 * MB;
    const files = [new MemoryFile('stream.bin', 32 * MB)];
    const env = makeEnv(files, {
      chunkSize,
      highWaterBytes: highWater,
      lowThresholdBytes: 512 * 1024,
      parallelChannels: 1,
    }, 1 * MB); // 1MB per tick drain
    await env.sender.run();
    const chan = env.dataA[0] as import('./util.js').MockChannel;
    // buffer must never exceed highWater by more than one in-flight chunk
    expect(chan.stats.maxBufferedSeen).toBeLessThanOrEqual(highWater + chunkSize);
    const sink = env.sinks.get(0)! as MemorySink;
    expect(sink.bytes).toBe(32 * MB);
  });

  it('emits progress events with speed/eta during transfer', async () => {
    const files = [new MemoryFile('p.bin', 64 * MB)];
    const env = makeEnv(files, { chunkSize: 128 * 1024, progressEveryMs: 20, parallelChannels: 1 }, 512 * 1024);
    const events: number[] = [];
    env.sender.on('progress', (p) => events.push(p.bytes));
    await env.sender.run();
    expect(events.length).toBeGreaterThanOrEqual(2);
    const sink = env.sinks.get(0)! as MemorySink;
    expect(sink.bytes).toBe(64 * MB);
  });
});

describe('resume after channel drop', () => {
  it('receiver reports last contiguous chunk; sender resumes; total wire bytes < full resend', async () => {
    const chunkSize = 256 * 1024;
    const files = [new MemoryFile('resume.bin', 24 * MB)];
    const sourceHash = sourceHex(files[0]!);
    const env = makeEnv(files, {
      chunkSize,
      highWaterBytes: MB,
      lowThresholdBytes: 256 * 1024,
      parallelChannels: 2,
      ackEvery: 2,
      progressEveryMs: 30,
    }, 256 * 1024); // ~256MB/s: kill lands ~2-6MB into a 24MB file

    let killed = false;
    const kill = () => {
      if (killed) return;
      killed = true;
      // simulate link death: close everything
      for (const ch of env.dataA) ch.close();
      env.controlPair.a.close();
    };

    // kill mid-transfer deterministically: onPersist(fileIndex, contiguousBytes) fires
    // every ackEvery=2 chunks (512KB of contiguous commits) → first callback past 2MB kills the link
    (env.receiver as unknown as Record<string, unknown>).onPersist = (_fileIndex: number, bytes: number) => {
      if (bytes >= 2 * MB) kill();
    };

    await expect(env.sender.run()).rejects.toThrow();

    // reconnect with fresh channels; same sender + receiver objects resume
    const freshControl = mockPair('control2');
    const freshDataA: import('../src/index.js').ChannelLike[] = [];
    const freshDataB: import('../src/index.js').ChannelLike[] = [];
    for (let i = 0; i < 2; i++) {
      const p = mockPair(`data2-${i}`, { bytesPerTick: 6 * MB, tickMs: 1 });
      freshDataA.push(p.a);
      freshDataB.push(p.b);
    }
    env.sender.attach({ control: freshControl.a, data: freshDataA });
    env.receiver.attach({ control: freshControl.b, data: freshDataB });

    const wireBefore = env.dataA.reduce((n, ch) => n + (ch as import('./util.js').MockChannel).stats.bytesSent, 0);
    await env.sender.run();
    const wireAfter = freshDataA.reduce((n, ch) => n + (ch as import('./util.js').MockChannel).stats.bytesSent, 0);

    const sink = env.sinks.get(0)! as MemorySink;
    expect(sink.bytes).toBe(24 * MB);
    expect(await sinkHex(sink)).toBe(await sourceHash);
    // resume actually skipped bytes: first leg sent some, second leg sent fewer than the full file
    expect(wireBefore).toBeGreaterThan(0);
    expect(wireAfter).toBeLessThan(24 * MB);
    expect(wireAfter).toBeGreaterThan(0);
  });
});

describe('memory bounds (spec: 4GB without >200MB growth)', () => {
  it('streams a 1GB file with bounded buffers on both sides', async () => {
    const chunkSize = 256 * 1024;
    const files = [new MemoryFile('tiny-ref.bin', 16 * MB), new MemoryFile('giant.bin', 1024 * MB)];
    const controlPair = mockPair('control');
    const dataA: import('../src/index.js').ChannelLike[] = [];
    const dataB: import('../src/index.js').ChannelLike[] = [];
    for (let i = 0; i < 4; i++) {
      const p = mockPair(`data-${i}`, { bytesPerTick: 64 * MB, tickMs: 0 });
      dataA.push(p.a);
      dataB.push(p.b);
    }
    const sinks = new Map<number, ByteSink>();
    sinks.set(0, new MemorySink());
    sinks.set(1, new CountingSink()); // count only: don't hold 1GB in test memory
    const sender = new TransferSender({
      id: 'big',
      files,
      config: { chunkSize, parallelThresholdBytes: MB, parallelChannels: 4, verifyThresholdBytes: MB },
    });
    sender.attach({ control: controlPair.a, data: dataA });
    const receiver = new TransferReceiver({
      sinkFor: async (i) => sinkHandle(sinks.get(i)!),
      config: { chunkSize, parallelThresholdBytes: MB, parallelChannels: 4, verifyThresholdBytes: MB },
    });
    receiver.attach({ control: controlPair.b, data: dataB });
    receiver.on('offer', () => void receiver.userAccept());

    const t0 = Date.now();
    await sender.run();
    const seconds = (Date.now() - t0) / 1000;

    expect((sinks.get(1)! as CountingSink).bytes).toBe(1024 * MB);
    expect((sinks.get(0)! as MemorySink).bytes).toBe(16 * MB);
    expect(await sinkHex(sinks.get(0)!)).toBe(await sourceHex(files[0]!));

    const maxBuffered = Math.max(...dataA.map((c) => (c as import('./util.js').MockChannel).stats.maxBufferedSeen));
    const slop = 4 * (CFG.highWaterBytes + chunkSize);
    expect(maxBuffered).toBeLessThanOrEqual(slop);
    expect(receiver.stats.maxPendingBytes).toBeLessThan(64 * MB);
    console.log(`[bench] 1GB through mock engine in ${seconds.toFixed(2)}s (${(1024 / seconds).toFixed(0)} MB/s), maxBuffered=${(maxBuffered / MB).toFixed(1)}MB, maxPending=${(receiver.stats.maxPendingBytes / MB).toFixed(1)}MB`);
  }, 120_000);
});

describe('chunk size negotiation', () => {
  it('keeps 256KB when the transport accepts it, falls back on rejection', async () => {
    const p1 = mockPair('neg-ok');
    const recv = new TransferReceiver({ sinkFor: async () => sinkHandle(new MemorySink()) });
    recv.attach({ control: p1.b, data: [mockPair('d').b] });
    await expect(negotiateChunkSize(p1.a, 256 * 1024, { timeoutMs: 1500 })).resolves.toBe(256 * 1024);

    // a transport that rejects messages above ~72KB — including string (control) sends
    class Picky extends MockChannel {
      send(data: string | ArrayBuffer | ArrayBufferView): void {
        const len = typeof data === 'string' ? data.length : (data as ArrayBuffer).byteLength;
        if (len > 64 * 1024 + 8 * 1024) {
          throw new TypeError('Message size exceeds maximum message size');
        }
        super.send(data);
      }
    }
    const a = new Picky('picky-a');
    const b = new Picky('picky-b');
    a.peer = b;
    b.peer = a;
    const recv2 = new TransferReceiver({ sinkFor: async () => sinkHandle(new MemorySink()) });
    recv2.attach({ control: b, data: [mockPair('d2').b] });
    await expect(negotiateChunkSize(a, 256 * 1024, { timeoutMs: 300 })).resolves.toBe(64 * 1024);
  });
});
