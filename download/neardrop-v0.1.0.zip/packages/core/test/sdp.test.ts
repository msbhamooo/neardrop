import { describe, expect, it } from 'vitest';
import { deflateRawSync, inflateRawSync } from 'node:zlib';
import {
  parseSdp, buildSdp, encodePayload, decodePayload,
  type CompactSdp, type Deflate, type Inflate,
} from '../src/index.js';

const deflate: Deflate = async (b) => new Uint8Array(deflateRawSync(Buffer.from(b)));
const inflate: Inflate = async (b) => new Uint8Array(inflateRawSync(Buffer.from(b)));

// A realistic fully-gathered offer SDP (mDNS candidate + v4 host candidate), as Chrome produces on LAN.
const SAMPLE_SDP = [
  'v=0',
  'o=- 4611731400430051336 2 IN IP4 127.0.0.1',
  's=-',
  't=0 0',
  'a=group:BUNDLE 0',
  'a=ice-options:trickle',
  'm=application 9 UDP/DTLS/SCTP webrtc-datachannel',
  'c=IN IP4 0.0.0.0',
  'a=ice-ufrag:4f7e',
  'a=ice-pwd:8BgKf3pR2xY9mZ1aQwL4Tn',
  'a=fingerprint:sha-256 19:E2:5C:68:9D:AB:34:71:F0:12:88:4C:56:0D:9A:3B:7C:1E:60:FA:22:5B:8D:41:0E:77:9F:C2:31:B5:64:8A',
  'a=setup:actpass',
  'a=mid:0',
  'a=sctp-port:5000',
  'a=max-message-size:262144',
  'a=candidate:1 1 udp 2122260223 192.168.1.42 54321 typ host',
  'a=candidate:1 1 udp 2122260223 a1b2c3d4-1234-5678-90ab-cdef01234567.local 54322 typ host',
].join('\r\n') + '\r\n';

describe('SDP minify/expand', () => {
  it('parses a fully-gathered offer', () => {
    const c = parseSdp(SAMPLE_SDP);
    expect(c.ufrag).toBe('4f7e');
    expect(c.pwd).toBe('8BgKf3pR2xY9mZ1aQwL4Tn');
    expect(c.setup).toBe('actpass');
    expect(c.fingerprint.length).toBe(32);
    expect(c.fingerprint[0]).toBe(0x19);
    expect(c.fingerprint[31]).toBe(0x8a);
    expect(c.candidates).toHaveLength(2);
    expect(c.candidates[0]).toMatchObject({ ip: '192.168.1.42', port: 54321, type: 'host', ipMode: 'v4' });
    expect(c.candidates[1]!.ipMode).toBe('mdns');
  });

  it('rebuilds an SDP that parses back identically', () => {
    const c = parseSdp(SAMPLE_SDP);
    const rebuilt = parseSdp(buildSdp(c));
    expect(rebuilt.ufrag).toBe(c.ufrag);
    expect(rebuilt.pwd).toBe(c.pwd);
    expect(rebuilt.setup).toBe(c.setup);
    expect(Array.from(rebuilt.fingerprint)).toEqual(Array.from(c.fingerprint));
    expect(rebuilt.candidates).toEqual(c.candidates);
  });

  it('encodes to a base45 payload small enough for QR error-correction M (<500 chars)', async () => {
    const c = parseSdp(SAMPLE_SDP);
    const payload = await encodePayload(c, deflate);
    expect(payload.length).toBeLessThan(500);
    expect(payload.length).toBeGreaterThan(20);
    const back = await decodePayload(payload, inflate);
    expect(back.ufrag).toBe(c.ufrag);
    expect(Array.from(back.fingerprint)).toEqual(Array.from(c.fingerprint));
    expect(back.candidates).toEqual(c.candidates);
  });

  it('round-trips uncompressed when no deflate adapter is given', async () => {
    const c = parseSdp(SAMPLE_SDP);
    const payload = await encodePayload(c);
    const back = await decodePayload(payload);
    expect(back.pwd).toBe(c.pwd);
  });

  it('rejects garbage payloads', async () => {
    await expect(decodePayload('QQQQQQQQQQ')).rejects.toThrow();
  });

  it('handles srflx candidates (TURN/STUN setups)', async () => {
    const sdp = SAMPLE_SDP.replace(
      'a=setup:actpass',
      'a=setup:actpass\r\na=candidate:2 1 udp 1686052607 203.0.113.7 60000 typ srflx raddr 10.0.0.4 rport 60000',
    );
    const c = parseSdp(sdp);
    expect(c.candidates.some((x) => x.type === 'srflx' && x.ip === '203.0.113.7')).toBe(true);
    const payload = await encodePayload(c, deflate);
    const back = await decodePayload(payload, inflate);
    expect(back.candidates).toEqual(c.candidates);
  });
});

describe('compact payload layout', () => {
  it('deflate flag stays outside the compressed stream', async () => {
    const c: CompactSdp = {
      setup: 'active',
      ufrag: 'abcdefgh',
      pwd: '0123456789abcdef01234567',
      fingerprint: new Uint8Array(32).fill(7),
      candidates: [
        { ipMode: 'v4', ip: '10.1.2.3', port: 12345, type: 'host', priority: 2113937151, foundation: '1', component: 1 },
      ],
    };
    const payload = await encodePayload(c, deflate);
    const back = await decodePayload(payload, inflate);
    expect(back.setup).toBe('active');
    expect(back.candidates[0]!.ip).toBe('10.1.2.3');
  });
});
