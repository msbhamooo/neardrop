import { describe, expect, it } from 'vitest';
import { encodeFrame, decodeFrame, FLAG_FINAL, encodeControl, parseControl } from '../src/index.js';
import { encodeBase45, decodeBase45 } from '../src/base45.js';
import { Sha256, sha256 } from '../src/sha256.js';
import { createHash } from 'node:crypto';

describe('binary frame codec', () => {
  it('round-trips header + payload', () => {
    const payload = new Uint8Array([1, 2, 3, 4, 5]);
    const frame = encodeFrame(513, 70000, FLAG_FINAL, payload);
    const parsed = decodeFrame(frame);
    expect(parsed.fileIndex).toBe(513);
    expect(parsed.chunkIndex).toBe(70000);
    expect(parsed.flags).toBe(FLAG_FINAL);
    expect(Array.from(parsed.payload)).toEqual([1, 2, 3, 4, 5]);
  });

  it('supports empty payload (zero-byte files)', () => {
    const frame = encodeFrame(0, 0, FLAG_FINAL, new Uint8Array(0));
    const parsed = decodeFrame(frame);
    expect(parsed.payload.byteLength).toBe(0);
  });

  it('encodes max values without overflow', () => {
    const frame = encodeFrame(65535, 0xffffffff, 0xffff, new Uint8Array(16).fill(9));
    const parsed = decodeFrame(frame);
    expect(parsed.fileIndex).toBe(65535);
    expect(parsed.chunkIndex).toBe(0xffffffff);
    expect(parsed.flags).toBe(0xffff);
  });
});

describe('control messages', () => {
  it('round-trips JSON control messages', () => {
    const msg = parseControl(encodeControl({ t: 'offer-files', id: 'x', files: [], totalBytes: 0, chunkSize: 1, channels: 1, compressed: [] }));
    expect(msg).not.toBeNull();
    expect(msg!.t).toBe('offer-files');
  });

  it('returns null on garbage', () => {
    expect(parseControl('not json')).toBeNull();
    expect(parseControl('{"t":123}')).toBeNull();
  });
});

describe('base45 (RFC 9285)', () => {
  it('matches the RFC example: "AB" → "BB8"', () => {
    expect(encodeBase45(new Uint8Array([65, 66]))).toBe('BB8');
  });

  it('round-trips random buffers of varied length', () => {
    for (const len of [0, 1, 2, 3, 7, 64, 255, 4096]) {
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) bytes[i] = (i * 37 + len) & 0xff;
      const decoded = decodeBase45(encodeBase45(bytes));
      expect(Array.from(decoded)).toEqual(Array.from(bytes));
    }
  });

  it('rejects invalid characters and dangling chars', () => {
    expect(() => decodeBase45('AB#')).toThrow();
    expect(() => decodeBase45('AB')).toThrow(); // dangling single char
  });
});

describe('incremental SHA-256', () => {
  it('matches known vectors', () => {
    expect(new Sha256().update(new TextEncoder().encode('abc')).digestHex())
      .toBe('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
    expect(new Sha256().digestHex())
      .toBe('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  });

  it('incremental == one-shot == node:crypto across chunk boundaries', () => {
    const bytes = new Uint8Array(100_000);
    for (let i = 0; i < bytes.length; i++) bytes[i] = (i * 31) & 0xff;
    const node = createHash('sha256').update(bytes).digest('hex');
    const h = new Sha256();
    // feed in awkward sizes to cross 64-byte block boundaries
    let off = 0;
    for (const n of [1, 7, 63, 64, 65, 130, 4096, 999]) {
      if (off >= bytes.length) break;
      h.update(bytes.subarray(off, Math.min(bytes.length, off + n)));
      off += n;
    }
    h.update(bytes.subarray(off));
    expect(h.digestHex()).toBe(node);
  });

  it('sha256() one-shot helper', () => {
    const node = createHash('sha256').update(new Uint8Array([1, 2, 3])).digest('hex');
    const out = sha256(new Uint8Array([1, 2, 3]));
    expect(Array.from(out).map((b) => b.toString(16).padStart(2, '0')).join('')).toBe(node);
  });
});
