import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import WebSocket from 'ws';
import { createSignalingServer, type SignalingServer } from '../src/create-server.js';
import { encodeGeohash, geohashNeighborhood } from '../src/geohash.js';

let server: SignalingServer;

function wsConnect(headers: Record<string, string> = {}): Promise<WebSocket> {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://localhost:${server.port}/`, { headers });
    ws.once('open', () => resolve(ws));
    ws.once('error', reject);
  });
}

function nextMessage(ws: WebSocket, timeoutMs = 3000): Promise<any> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout waiting for message')), timeoutMs);
    ws.once('message', (data) => {
      clearTimeout(timer);
      resolve(JSON.parse(String(data)));
    });
  });
}

/** Collect messages until a predicate matches (checks all buffered + new ones). */
async function waitFor(ws: WebSocket, pred: (msg: any) => boolean, timeoutMs = 3000): Promise<any> {
  const collected: any[] = [];
  const waiter = new Promise<any>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout waiting for predicate')), timeoutMs);
    const onMsg = (data: any) => {
      const msg = JSON.parse(String(data));
      collected.push(msg);
      if (pred(msg)) {
        clearTimeout(timer);
        resolve(msg);
      }
    };
    ws.on('message', onMsg);
  });
  const result = await waiter;
  // re-queue non-matching messages for later assertions? keep simple: return first match
  return result;
}

async function join(ws: WebSocket, id: string, name = 'Test', extra: Record<string, unknown> = {}): Promise<void> {
  ws.send(JSON.stringify({ t: 'join', id, name, deviceType: 'laptop', ...extra }));
}

beforeEach(async () => {
  server = await createSignalingServer({ port: 0 });
});

afterEach(async () => {
  await server.close();
});

describe('geohash', () => {
  it('matches the canonical example (57.64911, 10.40744 → u4pruydq)', () => {
    expect(encodeGeohash(57.64911, 10.40744, 8)).toBe('u4pruydq');
  });

  it('produces a 9-cell neighborhood', () => {
    const n = geohashNeighborhood('u4pruydq');
    expect(n).toHaveLength(9);
    expect(n).toContain('u4pruydq');
  });
});

describe('rooms & discovery', () => {
  it('peers on the same IP see each other (welcome + peer-joined)', async () => {
    const a = await wsConnect();
    const b = await wsConnect();
    await join(a, 'device-aaaaaaaa', 'Alpha');
    await join(b, 'device-bbbbbbbb', 'Beta');

    const aSees = await waitFor(a, (m) => m.t === 'peer-joined');
    expect(aSees.peer.id).toBe('device-bbbbbbbb');
    expect(aSees.peer.sameNetwork).toBe(true);

    const bWelcome = await waitFor(b, (m) => m.t === 'welcome');
    expect(bWelcome.peers.map((p: any) => p.id)).toContain('device-aaaaaaaa');

    a.close();
    b.close();
  });

  it('different public IPs are invisible to each other', async () => {
    const s2 = await createSignalingServer({ port: 0, trustProxy: true });
    const a = new WebSocket(`ws://localhost:${s2.port}/`, { headers: { 'x-forwarded-for': '1.2.3.4' } });
    const b = new WebSocket(`ws://localhost:${s2.port}/`, { headers: { 'x-forwarded-for': '5.6.7.8' } });
    await Promise.all([new Promise<void>((r) => a.once('open', () => r())), new Promise<void>((r) => b.once('open', () => r()))]);
    await join(a, 'device-aaaaaaaa', 'Alpha');
    await join(b, 'device-bbbbbbbb', 'Beta');
    const welcomeB = await nextMessage(b); // welcome
    expect(welcomeB.peers).toHaveLength(0);
    // b signals to a → unknown-peer
    b.send(JSON.stringify({ t: 'signal', to: 'device-aaaaaaaa', data: { sdp: 'x' } }));
    const err = await waitFor(b, (m) => m.t === 'error');
    expect(err.code).toBe('unknown-peer');
    a.close();
    b.close();
    await s2.close();
  });

  it('adjacent geohash cells make cross-IP peers visible', async () => {
    const s2 = await createSignalingServer({ port: 0, trustProxy: true });
    const a = new WebSocket(`ws://localhost:${s2.port}/`, { headers: { 'x-forwarded-for': '1.2.3.4' } });
    const b = new WebSocket(`ws://localhost:${s2.port}/`, { headers: { 'x-forwarded-for': '5.6.7.8' } });
    await Promise.all([new Promise<void>((r) => a.once('open', () => r())), new Promise<void>((r) => b.once('open', () => r()))]);
    const cellA = encodeGeohash(48.137154, 11.58631, 8); // Marienplatz, Munich
    const cellB = encodeGeohash(48.137154 + 0.00025, 11.58631, 8); // one cell north (~1.45 cells offset) → 'u281zehu'
    await join(a, 'device-aaaaaaaa', 'Alpha', { geo: cellA });
    await join(b, 'device-bbbbbbbb', 'Beta', { geo: cellB });
    const welcomeB = await nextMessage(b);
    expect(welcomeB.peers.map((p: any) => p.id)).toContain('device-aaaaaaaa');
    expect(welcomeB.peers[0].sameNetwork).toBe(false);
    a.close();
    b.close();
    await s2.close();
  });

  it('peer-left is broadcast when a peer disconnects', async () => {
    const a = await wsConnect();
    const b = await wsConnect();
    await join(a, 'device-aaaaaaaa', 'Alpha');
    await join(b, 'device-bbbbbbbb', 'Beta');
    await waitFor(a, (m) => m.t === 'peer-joined');
    b.close();
    const left = await waitFor(a, (m) => m.t === 'peer-left');
    expect(left.id).toBe('device-bbbbbbbb');
    a.close();
  });
});

describe('relay & guards', () => {
  it('relays opaque signal payloads between visible peers', async () => {
    const a = await wsConnect();
    const b = await wsConnect();
    await join(a, 'device-aaaaaaaa', 'Alpha');
    await join(b, 'device-bbbbbbbb', 'Beta');
    await waitFor(a, (m) => m.t === 'peer-joined');
    const payload = { sdp: { type: 'offer', sdp: 'v=0...\u0000binary-ish' }, huge: 'x'.repeat(4000) };
    a.send(JSON.stringify({ t: 'signal', to: 'device-bbbbbbbb', data: payload }));
    const got = await waitFor(b, (m) => m.t === 'signal');
    expect(got.from).toBe('device-aaaaaaaa');
    expect(got.data).toEqual(payload);
    a.close();
    b.close();
  });

  it('rejects joins without identity and sanitizes names', async () => {
    const a = await wsConnect();
    a.send(JSON.stringify({ t: 'join', id: 'x', name: '' }));
    const err = await waitFor(a, (m) => m.t === 'error');
    expect(err.code).toBe('bad-message');
    a.close();
  });

  it('rate-limits floods and terminates repeat offenders', async () => {
    const a = await wsConnect();
    await join(a, 'device-aaaaaaaa', 'Alpha');
    let rateLimited = 0;
    const closed = new Promise<void>((resolve) => a.once('close', () => resolve()));
    a.on('message', (data) => {
      const msg = JSON.parse(String(data));
      if (msg.t === 'error' && msg.code === 'rate-limited') rateLimited += 1;
    });
    // flood: bucket capacity 40, refill 12/s → 100 rapid messages trip it
    for (let i = 0; i < 100; i++) {
      a.send(JSON.stringify({ t: 'signal', to: 'nope', data: 1 }));
    }
    await new Promise((r) => setTimeout(r, 300));
    expect(rateLimited).toBeGreaterThanOrEqual(1);
    // 3 strikes → terminate
    for (let i = 0; i < 200; i++) a.send(JSON.stringify({ t: 'signal', to: 'nope', data: 1 }));
    await closed;
  });

  it('signals before joining are rejected', async () => {
    const a = await wsConnect();
    a.send(JSON.stringify({ t: 'signal', to: 'anyone', data: { sdp: 1 } }));
    const err = await waitFor(a, (m) => m.t === 'error');
    expect(err.code).toBe('not-joined');
    a.close();
  });
});
